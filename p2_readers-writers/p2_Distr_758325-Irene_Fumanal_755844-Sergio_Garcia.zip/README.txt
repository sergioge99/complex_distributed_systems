
Para compilar y abrir cada nodo, utilizamos el script 'ini.sh' o 'localini.sh', el script compila
los archivos: rw.ex y repositorio.exs.

En el nodo en el que se lance el gestor:
	-Lanzar la funcion Gestor.escenario1.
