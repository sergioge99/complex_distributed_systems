
Para compilar y abrir cada nodo, utilizamos el script 'ini.sh', el script compila
los archivos: escenario1.ex, escenario2.ex y escenario3.ex (incluyen modulo fibonacci).
IMPORTANTE: en el modulo Ini del escenario elegido habrá que escribir tantas lineas 
como máquinas se utilicen indicando su nodo (en el escenario 3 incluir minimo 3 nodos).

En el nodo en el que se lance el cliente:
	-Compilar cliente.ex
	-Lanzar la funcion Ini1.iniciar, Ini2.iniciar o Ini3.iniciar dependiendo del 
	escenario.
