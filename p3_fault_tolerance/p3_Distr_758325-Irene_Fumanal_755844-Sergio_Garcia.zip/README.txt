
Para compilar y abrir cada nodo, utilizamos el script 'ini.sh' o 'localini.sh', el script compila
los archivos: practica3.ex

Para iniciar:
	-Tiene que haber 4 nodos abiertos en cada máquina (un worker por nodo)
	-Hay que reescribir el modulo Init para que haga los correctos connect con los nodos
	-En el nodo que se lance el servidor, hay que ejecutar "Init.iniciar"
